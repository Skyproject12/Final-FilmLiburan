package com.example.filmliburan.Util;

public class Static {
    public static String API_KEY="412327d8b23a411e90711834b24fe08e";
}
